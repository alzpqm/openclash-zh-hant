#!/bin/bash
set -euo pipefail
ENV_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
PROJECT_DIR="${OPENCLASH_PROJECT_DIR:-/workspace/openclash-zh-hant}"
SDK_IMAGE=ghcr.io/openwrt/sdk@sha256:e916b7cc555890bdc4725c926e139b888294f0c8f56561b88d8da3a6348616a2
TOOLS_IMAGE=debian:13-slim@sha256:a29215f6a35e51e22adffa17f89e9d2ef06214e64a2bad10d765c46aea49f11f
docker_cli() {
  env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH \
    docker --host=unix:///var/run/docker.sock "$@"
}
docker_cli info >/dev/null
test -f "$PROJECT_DIR/luci-app-openclash/Makefile"
test -r "${CODEX_PROXY_CERT:?The managed proxy CA is required}"
mkdir -p "$ENV_DIR/logs" "$ENV_DIR/keys"
chmod 700 "$ENV_DIR/keys"
for name in openclash-sdk openclash-tools; do
  image="$SDK_IMAGE"
  [ "$name" != openclash-tools ] || image="$TOOLS_IMAGE"
  if docker_cli container inspect "$name" >/dev/null 2>&1; then
    test "$(docker_cli inspect --format '{{.Config.Image}}' "$name")" = "$image"
    test "$(docker_cli inspect --format '{{range .Mounts}}{{if eq .Destination "/source"}}{{.Source}}{{end}}{{end}}' "$name")" = "$PROJECT_DIR"
    test "$(docker_cli inspect --format '{{range .Mounts}}{{if eq .Destination "/work"}}{{.Source}}{{end}}{{end}}' "$name")" = "$ENV_DIR"
    if [ "$(docker_cli inspect --format '{{.State.Running}}' "$name")" != true ]; then docker_cli start "$name" >/dev/null; fi
  else
    docker_cli pull "$image"
    docker_cli run -d --name "$name" \
      --mount "type=bind,src=$PROJECT_DIR,dst=/source" \
      --mount "type=bind,src=$ENV_DIR,dst=/work" \
      --mount type=bind,src=/etc/ssl/certs/ca-certificates.crt,dst=/run/codex-ca-bundle.crt,readonly \
      --mount "type=bind,src=$CODEX_PROXY_CERT,dst=/run/codex-proxy-ca.crt,readonly" \
      -e CURL_CA_BUNDLE=/run/codex-ca-bundle.crt -e SSL_CERT_FILE=/run/codex-ca-bundle.crt \
      -e REQUESTS_CA_BUNDLE=/run/codex-ca-bundle.crt -e GIT_SSL_CAINFO=/run/codex-ca-bundle.crt \
      --entrypoint /bin/bash "$image" -lc 'sleep infinity'
  fi
done
docker_cli exec openclash-tools /bin/bash -lc 'command -v msgfmt && command -v ruby && command -v luac' >/dev/null || \
  docker_cli exec openclash-tools /bin/bash -lc 'set -e; sed -i "s|http://deb.debian.org|https://deb.debian.org|g" /etc/apt/sources.list.d/debian.sources; apt-get -o Acquire::https::CaInfo=/run/codex-ca-bundle.crt update; DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::https::CaInfo=/run/codex-ca-bundle.crt install -y --no-install-recommends ca-certificates gettext ruby ruby-yaml lua5.1 python3; install -m 0644 /run/codex-proxy-ca.crt /usr/local/share/ca-certificates/codex-session.crt; update-ca-certificates'
docker_cli exec openclash-sdk /bin/bash -lc 'set -e; if [ ! -d feeds/base ] || [ ! -d feeds/packages ] || [ ! -d feeds/luci ]; then install -m 0644 /run/codex-proxy-ca.crt /usr/local/share/ca-certificates/codex-session.crt; update-ca-certificates; cd /builder; ./scripts/feeds update base packages luci; ./scripts/feeds install -a -p base; ./scripts/feeds install -a -p packages; ./scripts/feeds install -a -p luci; fi'
for spec in base:f0a60eee2fe051741c643ea6118718aae1ef17fb packages:5caa62e0bc9f7fb9b0c12a23267bceb7724214dd luci:128a7812f4be233c5dd7f7466f534fd888785caf; do
  feed=${spec%%:*}
  expected=${spec#*:}
  test "$(docker_cli exec openclash-sdk git -C "/builder/feeds/$feed" rev-parse HEAD)" = "$expected"
done
if [ ! -s "$ENV_DIR/keys/development.pem" ]; then
  (umask 077; openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:4096 -out "$ENV_DIR/keys/development.pem" >"$ENV_DIR/logs/key-generation.log" 2>&1)
fi
openssl pkey -in "$ENV_DIR/keys/development.pem" -pubout -out "$ENV_DIR/keys/development.pem.pub"
chmod 600 "$ENV_DIR/keys/development.pem"
chmod 644 "$ENV_DIR/keys/development.pem.pub"
printf 'Pinned SDK and validation tools are ready; signing uses a local development key.\n'
