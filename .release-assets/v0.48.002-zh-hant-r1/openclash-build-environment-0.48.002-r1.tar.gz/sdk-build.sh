#!/bin/bash
set -euo pipefail
ENV_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH \
  docker --host=unix:///var/run/docker.sock exec -e LANG=C.UTF-8 -e LC_ALL=C.UTF-8 \
  openclash-sdk /bin/bash /work/sdk-build-inner.sh >"$ENV_DIR/logs/sdk-build.log" 2>&1
printf 'SDK packages built and signatures verified. Log: %s\n' "$ENV_DIR/logs/sdk-build.log"
