#!/bin/bash
set -euo pipefail
cd /builder
export STAGING_DIR_HOST=/builder/staging_dir/host
export PATH="$STAGING_DIR_HOST/bin:$PATH"
export OPENCLASH_APK_SIGN_KEY=/work/keys/development.pem
VERSION=$(sed -n 's/^PKG_VERSION:=//p' /source/luci-app-openclash/Makefile)
RELEASE=$(sed -n 's/^PKG_RELEASE:=//p' /source/luci-app-openclash/Makefile)
# The official SDK recipe emits unsigned APKs. Sign at package creation so
# verification never needs to accept an unsigned or untrusted intermediate.
python3 - <<'PY'
from pathlib import Path
p = Path('/builder/include/package-pack.mk')
text = p.read_text()
needle = '\t$(FAKEROOT) $(STAGING_DIR_HOST)/bin/apk mkpkg \\\n'
if '$(OPENCLASH_APK_SIGN_KEY)' not in text:
    assert text.count(needle) == 1
    text = text.replace(needle, needle + '\t  --sign-key "$(OPENCLASH_APK_SIGN_KEY)" \\\n')
    p.write_text(text)
PY
mkdir -p package/local /work/artifacts/sdk
rm -rf package/local/luci-app-openclash package/local/luci-i18n-openclash-zh-hant
cp -a /source/luci-app-openclash /source/luci-i18n-openclash-zh-hant package/local/
cc -O2 -I/source/luci-app-openclash/tools/po2lmo/src \
  -o staging_dir/host/bin/po2lmo \
  /source/luci-app-openclash/tools/po2lmo/src/po2lmo.c \
  /source/luci-app-openclash/tools/po2lmo/src/template_lmo.c
cat > .config <<'EOF'
CONFIG_TARGET_x86=y
CONFIG_TARGET_x86_64=y
CONFIG_TARGET_x86_64_DEVICE_generic=y
CONFIG_ALL_NONSHARED=n
CONFIG_ALL_KMODS=n
CONFIG_ALL=n
CONFIG_SIGNATURE_CHECK=y
CONFIG_DOWNLOAD_CHECK_CERTIFICATE=y
CONFIG_PACKAGE_luci-app-openclash=m
CONFIG_PACKAGE_luci-i18n-openclash-zh-hant=m
EOF
make defconfig
# These are architecture-independent LuCI packages with no target compilation.
# Invoke their SDK package Makefiles directly rather than recursively rebuilding
# firmware dependencies (including Rust/LLVM and host Ruby).
make -C package/local/luci-app-openclash TOPDIR=/builder clean compile V=s
make -C package/local/luci-i18n-openclash-zh-hant TOPDIR=/builder clean compile V=s
for name in luci-app-openclash luci-i18n-openclash-zh-hant; do
  artifact=$(find bin/packages -name "$name-$VERSION-r$RELEASE.apk" -print -quit)
  test -n "$artifact"
  staging_dir/host/bin/apk --keys-dir /work/keys verify "$artifact"
  cp "$artifact" /work/artifacts/sdk/
done
cp .config /work/artifacts/sdk/sdk.config
cp staging_dir/toolchain-*/info.mk /work/artifacts/sdk/toolchain.info.mk
cp feeds.conf.default /work/artifacts/sdk/feeds.conf.default
make -C package/local/luci-app-openclash TOPDIR=/builder CONFIG_USE_APK= clean compile V=s
make -C package/local/luci-i18n-openclash-zh-hant TOPDIR=/builder CONFIG_USE_APK= clean compile V=s
find bin/packages -name "*openclash*_${VERSION}-r${RELEASE}_all.ipk" -exec cp {} /work/artifacts/sdk/ \;
