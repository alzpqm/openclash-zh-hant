#!/bin/bash
set -euo pipefail
ENV_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
PROJECT_DIR="${OPENCLASH_PROJECT_DIR:-/workspace/openclash-zh-hant}"
if ! PYTHONPATH="$ENV_DIR/python" python3 -c 'import polib, opencc' 2>/dev/null; then
  python3 -m pip install --target "$ENV_DIR/python" polib==1.2.0 opencc-python-reimplemented==0.1.7
fi
bash "$ENV_DIR/sdk-install.sh"
sources="$PROJECT_DIR/luci-app-openclash/tools/po2lmo/src"
cc -O2 -I"$sources" -o "$ENV_DIR/po2lmo" "$sources/po2lmo.c" "$sources/template_lmo.c"
cc -O2 -fPIC -shared -I"$sources" -o "$ENV_DIR/liblmo.so" "$sources/template_lmo.c"
printf 'Use: source %s/activate.sh\n' "$ENV_DIR"
