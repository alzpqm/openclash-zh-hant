#!/usr/bin/env python3
"""Run source, catalog, Ruby YAML and package checks in the restored environment."""
import json
import os
import subprocess
from pathlib import Path

ENV = Path(__file__).resolve().parent
ROOT = Path('/workspace/openclash-zh-hant')

def run(args, **kwargs):
    return subprocess.run(args, check=True, capture_output=True, text=True, **kwargs)

def main():
    environment = dict(os.environ)
    environment['PYTHONPATH'] = str(ENV/'python')
    catalog = json.loads(run(['python3', str(ROOT/'tools/validate-localization.py')], env=environment).stdout)
    run(['docker','exec','openclash-tools','msgfmt','--check','--check-format','-o','/tmp/openclash-catalog.mo','/source/luci-app-openclash/po/zh_Hant/openclash.zh_Hant.po'])
    lua = list((ROOT/'luci-app-openclash').rglob('*.lua'))
    ruby = list((ROOT/'luci-app-openclash').rglob('*.rb'))
    javascript = list((ROOT/'luci-app-openclash/root/www/luci-static/resources/openclash/js').glob('*.js'))
    shell = list((ROOT/'luci-app-openclash').rglob('*.sh'))+[ROOT/'luci-app-openclash/root/etc/init.d/openclash']+list((ROOT/'tools').glob('*.sh'))+list(ENV.glob('*.sh'))
    for path in lua:
        run(['docker','exec','openclash-tools','luac','-p','/source/'+str(path.relative_to(ROOT))])
    for path in ruby:
        run(['docker','exec','openclash-tools','ruby','-c','/source/'+str(path.relative_to(ROOT))])
    for path in javascript:
        run(['node','--check',str(path)])
    for path in shell:
        run(['bash','-n',str(path)])
    yaml_fixture = '''# encoding: UTF-8
require 'yaml'
require 'YAML'
require 'tmpdir'
# This plain-YAML fixture disables optional router UCI/age-key configuration.
def YAML.age_keys_enabled?; false; end
files = Dir['/source/luci-app-openclash/**/*.yaml']
Dir.mktmpdir do |dir|
  files.each_with_index do |file, i|
    before = YAML.load_file(file)
    next if before.nil? || before == false
    out = File.join(dir, "#{i}.yaml")
    YAML.dump_to_path(before, out)
    raise "YAML round-trip mismatch: #{file}" unless YAML.load_file(out) == before
  end
  sample = {'proxies'=>[{'name'=>'正體中文測試節點','type'=>'vless','reality-opts'=>{'short-id'=>'00123abc'}}], 'dns'=>{'nameserver-policy'=>{'geosite:cn'=>'https://dns.google/dns-query'}}}
  out = File.join(dir,'sample.yaml')
  YAML.dump_to_path(sample,out)
  raise 'Chinese/short-id round-trip mismatch' unless YAML.load_file(out) == sample
end
puts files.length
'''
    yaml_files = int(run(['docker','exec','-i','-e','LANG=C.UTF-8','-e','LC_ALL=C.UTF-8','openclash-tools','ruby','-I/source/luci-app-openclash/root/usr/share/openclash','-'], input=yaml_fixture).stdout.strip())
    run(['python3',str(ENV/'sdk-validate.py')])
    packages = json.loads((ENV/'sdk-validation.json').read_text())
    result = {
        'upstream_tag':'v0.48.002', 'upstream_sha':'e553e82e01c697aefbe1555261a503f425e00ccd',
        'sdk_image':'ghcr.io/openwrt/sdk@sha256:e916b7cc555890bdc4725c926e139b888294f0c8f56561b88d8da3a6348616a2',
        'sdk_version':'OpenWrt 25.12.5 x86-64; GCC 14.3.0; musl 1.2.5',
        'catalog':catalog,
        'source_checks':{'lua_files':len(lua),'ruby_files':len(ruby),'javascript_files':len(javascript),'shell_files':len(shell),'gettext_format':'passed','ruby_yaml_fixtures':yaml_files,'ruby_yaml_chinese_and_short_id_round_trip':'passed'},
        'packages':packages,
        'installation_script_repeated_runs':2,
        'limitations':['Not tested on a physical OpenWrt router.','No firmware dependencies or native cores were rebuilt.','APK signatures use a local development key, not an official release key.']
    }
    (ENV/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
