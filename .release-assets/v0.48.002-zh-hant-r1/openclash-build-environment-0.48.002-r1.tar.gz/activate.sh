#!/bin/bash
# Source this file in the host shell; credentials and proxy settings stay inherited.
export OPENCLASH_ENV_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export OPENCLASH_PROJECT_DIR="${OPENCLASH_PROJECT_DIR:-/workspace/openclash-zh-hant}"
export PYTHONPATH="$OPENCLASH_ENV_DIR/python${PYTHONPATH:+:$PYTHONPATH}"
export PATH="$OPENCLASH_ENV_DIR:$PATH"
openclash_sdk() {
  env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH \
    docker --host=unix:///var/run/docker.sock exec -e LANG=C.UTF-8 -e LC_ALL=C.UTF-8 openclash-sdk "$@"
}
openclash_validate() {
  python3 "$OPENCLASH_PROJECT_DIR/tools/validate-localization.py"
}
