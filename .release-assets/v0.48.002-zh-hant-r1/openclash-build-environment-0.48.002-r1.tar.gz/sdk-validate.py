#!/usr/bin/env python3
"""Check the built packages, signature rejection and exact installed payloads."""
import hashlib
import io
import json
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

ENV = Path(__file__).resolve().parent
ROOT = Path('/workspace/openclash-zh-hant')
APK = '/builder/staging_dir/host/bin/apk'

def sdk(*args, check=True):
    return subprocess.run(['docker', 'exec', 'openclash-sdk', APK, *args], capture_output=True, text=True, check=check)

def inner_path(path):
    return '/work/' + str(path.relative_to(ENV))

def ipk_members(path):
    data = path.read_bytes()
    if data.startswith(b'!<arch>\n'):
        members, pos = {}, 8
        while pos < len(data):
            header = data[pos:pos+60]
            assert header[-2:] == b'`\n'
            name = header[:16].decode().strip().rstrip('/')
            size = int(header[48:58])
            pos += 60
            members[name] = data[pos:pos+size]
            pos += size + size % 2
        return members
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as archive:
        return {m.name.removeprefix('./'): archive.extractfile(m).read() for m in archive if m.isfile()}

def validate():
    artifacts = sorted((ENV/'artifacts/sdk').glob('*.apk')) + sorted((ENV/'artifacts/standalone').glob('*.apk'))
    negative = ENV/'apk-negative'
    (negative/'empty-keys').mkdir(parents=True, exist_ok=True)
    extracted = {}
    for i, artifact in enumerate(artifacts):
        apk_path = inner_path(artifact)
        sdk('--keys-dir', '/work/keys', 'verify', apk_path)
        assert sdk('--keys-dir', '/work/apk-negative/empty-keys', 'verify', apk_path, check=False).returncode != 0, 'Accepted a missing trusted key'
        broken = bytearray(artifact.read_bytes())
        broken[len(broken)//2] ^= 0x80
        tampered = negative/f'tampered-{i}.apk'
        tampered.write_bytes(broken)
        assert sdk('--keys-dir', '/work/keys', 'verify', inner_path(tampered), check=False).returncode != 0, 'Accepted damaged data'
        tampered.unlink()
        dump = sdk('--keys-dir', '/work/keys', 'adbdump', apk_path).stdout
        assert 'arch: noarch' in dump and 'version: 0.48.002-r1' in dump
        assert all(line.strip() in ('user: root', 'group: root') for line in dump.splitlines() if line.strip().startswith(('user:', 'group:'))), 'Incorrect APK ownership'
        destination = ENV/'package-extract'/f'apk-{i}'
        if destination.exists():
            shutil.rmtree(destination)
        destination.mkdir(parents=True, exist_ok=True)
        sdk('--keys-dir', '/work/keys', 'extract', '--no-chown', '--destination', inner_path(destination), apk_path)
        extracted[str(artifact.relative_to(ENV))] = destination
    expected_lmo = ENV/'lmo/openclash.zh-tw.lmo'
    subprocess.run([str(ENV/'po2lmo'), str(ROOT/'luci-app-openclash/po/zh_Hant/openclash.zh_Hant.po'), str(expected_lmo)], check=True)
    expected = expected_lmo.read_bytes()
    for destination in extracted.values():
        for name in ('openclash.zh-tw.lmo', 'openclash.zh-hant.lmo', 'openclash.zh_Hant.lmo'):
            assert (destination/'usr/lib/lua/luci/i18n'/name).read_bytes() == expected, f'APK LMO mismatch: {destination}/{name}'

    ipks = list((ENV/'artifacts/sdk').glob('*.ipk')) + list((ENV/'artifacts/standalone').glob('*.ipk'))
    for artifact in ipks:
        outer = ipk_members(artifact)
        assert outer['debian-binary'] == b'2.0\n'
        with tarfile.open(fileobj=io.BytesIO(outer['control.tar.gz'])) as control:
            metadata = next(control.extractfile(m).read().decode() for m in control if m.name.removeprefix('./') == 'control')
            assert 'Architecture: all' in metadata and 'Version: 0.48.002-' in metadata
        with tarfile.open(fileobj=io.BytesIO(outer['data.tar.gz'])) as data:
            entries = data.getmembers()
            assert all(m.uid == 0 and m.gid == 0 for m in entries)
            lookup = {m.name.removeprefix('./').rstrip('/'): m for m in entries}
            for lang in ('zh-tw', 'zh-hant', 'zh_Hant'):
                name = f'usr/lib/lua/luci/i18n/openclash.{lang}.lmo'
                entry = lookup[name]
                if entry.issym():
                    entry = lookup[str(Path(name).parent/entry.linkname)]
                assert data.extractfile(entry).read() == expected, f'IPK LMO mismatch: {artifact.name}'

    main = next(dest for name, dest in extracted.items() if Path(name).name.startswith('luci-app-openclash-'))
    files_checked = 0
    for directory, installed in ((ROOT/'luci-app-openclash/root', main), (ROOT/'luci-app-openclash/luasrc', main/'usr/lib/lua/luci')):
        for source in directory.rglob('*'):
            if not source.is_file():
                continue
            expected_data = source.read_bytes()
            relative = source.relative_to(directory)
            if directory.name == 'luasrc' and (relative == Path('openclash.lua') or relative.suffix == '.htm'):
                expected_data = expected_data.replace(b'@OPENCLASH_VERSION@', b'0.48.002')
            assert (installed/relative).read_bytes() == expected_data, f'Packaged source differs: {relative}'
            files_checked += 1
    assert b'--allow-untrusted' not in (main/'usr/share/openclash/openclash_update.sh').read_bytes()
    return {'apk_packages': len(artifacts), 'ipk_packages': len(ipks), 'signature_validation': 'passed', 'missing_key_rejection': 'passed', 'damaged_package_rejection': 'passed', 'package_root_ownership': 'passed', 'language_aliases': ['zh-tw', 'zh-hant', 'zh_Hant'], 'packaged_main_source_files_verified': files_checked, 'lmo_sha256': hashlib.sha256(expected).hexdigest(), 'signing': 'local development key; not an official OpenWrt release signature'}

if __name__ == '__main__':
    result = validate()
    (ENV/'sdk-validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
